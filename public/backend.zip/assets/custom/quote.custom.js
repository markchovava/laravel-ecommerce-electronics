
$('.calculate__grandtotal').click(function(e){
    e.preventDefault();
    let product__sum = $(this).closest('tfoot').siblings('tbody').find('.product__sum');
    let sub__total = $(this).closest('tfoot').find('.sub__total');
    let quote__tax = $(this).closest('tfoot').find('.quote__tax').val();
    let quote__discount = $(this).closest('tfoot').find('.quote__discount').val();
    let grand__total = $(this).closest('tfoot').find('.grand__total');
    let product__sumTotal = new Array();
    $('.product__sum').each((i, item) => {
        product__sumTotal.push(item.value);
    }); 
    
    // Sub Total Calculation
    if(product__sumTotal.length == 1){
        var product_singleTotal = Number(product__sumTotal[0]);
        var subtotal = product_singleTotal.toFixed(2); // For Display
        var subtotal_raw = product_singleTotal; // For calculations
        if( quote__tax != '' && quote__discount != ''){
            if(isNaN(quote__tax) && isNaN(quote__discount)){
                var tax = Number(quote__tax);
                var discount = Number(quote__discount);
            }else{
                var tax = quote__tax;
                var discount = quote__discount;
            }
            var calculate__tax = (tax / 100) * subtotal_raw;
            var calculate__discount = (discount / 100) * subtotal_raw;
            var total__calculator = (subtotal_raw  + calculate__tax) - calculate__discount;
            var grandtotal = total__calculator.toFixed(2);
            sub__total.val( subtotal );
            grand__total.val( grandtotal );       
        } else{
            sub__total.val( subtotal );
            grand__total.val( subtotal );
        }

    }  
    else
    {
        var product__listTotal = product__sumTotal.reduce((a, b) => Number(a) + Number(b));
        var subtotal = product__listTotal.toFixed(2);
        var subtotal_raw = Number(product__listTotal);
        if( quote__tax != '' && quote__discount != ''){
            if(isNaN(quote__tax) && isNaN(quote__discount)){
                var tax = Number(quote__tax);
                var discount = Number(quote__discount);
            }else{
                var tax = quote__tax;
                var discount = quote__discount;
            }
            var calculate__tax = (tax / 100) * subtotal_raw;
            var calculate__discount = (discount / 100) * subtotal_raw;
            var total__calculator = (subtotal_raw  + calculate__tax) - calculate__discount;
            var grandtotal = total__calculator.toFixed(2);
            sub__total.val( subtotal );
            grand__total.val( grandtotal );
        } else{
            sub__total.val( subtotal );
            grand__total.val( subtotal );
        }

    } 

});

// Clone and Add Product Item
 $(document).on('click', '.add__productItem', function(e){
     e.preventDefault();
     var product__searchItem = $(".product__searchItem");
     var product_searchInput = product__searchItem.find('.product__name').val();
     var product__searchPrice = product__searchItem.find('.product__priceInsert').val();
     
     var product__first = $(".product__item:first");
     var product__firstInput = product__first.find('.product__name');
     var product__firstPrice = product__first.find('.product__priceInsert');
     product__firstInput.val(product_searchInput);
     product__firstPrice.val(product__searchPrice);
     //Cloning the first tr
     var item__clone = $(".product__item:first").clone();
     item__clone.removeClass('display__none');
     // Adding attributes
     item__clone.find('.product__name').attr('name','product_name[]');
     item__clone.find('.product__descriptionInsert').attr('name','description[]');
     item__clone.find('.product__quantityInsert').attr('name','quantity[]');
     item__clone.find('.product__priceInsert').attr('name','price[]');
     item__clone.find('input[type="hidden"]').attr('name','product_total[]').addClass('product__sum');
     $(".product__insertArea").append(item__clone);     
 });

$(document).on('click', '.remove__productItem', function(e){
    e.preventDefault();
    var item__remove = $(this).closest('.product__item').remove();
});

 $('#search__btn').click(function(e){
    if(this.id == "search__btn"){
        var product_name = $(this).closest('.product__search').find('.product__name').val();
        var product__results = $(this).closest('.product__search').find('.product__results')
        //product__results.addClass('display__block');
        e.preventDefault();
        if( product_name != "" ){
            product__results.addClass('display__block').append('<li class="results__pretext text-success">Loading...</li>');
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: $(this).attr('href'),
                method: "GET",
                dataType: 'json',
                data: {
                    name: product_name,
                },
                success: function(res){
                    console.log(res.product);
                    if(res.product.length > 0){
                        product__results.empty();
                        for(var i = 0; i< res.product.length; i++){
                            $.each(res, function () {
                                product__results
                                .append('<li price="' + res.product[i].price + '" id="' + res.product[i].id + '">' + res.product[i].name + '</li>');
                            });
                        }
                    } else{
                        product__results.empty();
                        product__results.append('<li class="text-danger">No Results.</li>');
                    }
                }
            });
        }
    }
    
 });

$(document).on('click', '.product__results li', function(e){
    var product__item = $(this).text();
    var product__id = $(this).attr('id');
    var product__price = $(this).attr('price');
    var product__priceNumber = Number(product__price);
    //alert(product__price);
    var product__list = $(this).closest('.product__results');
    var product__value = $(this).closest('.product__search').find('.product__name');
    var product__priceInsert = $(this).closest('.product__searchItem').find('.product__priceInsert');
    if(product__item != "No Results."){
        product__value.val(product__item);
        product__priceInsert.val(product__price);
    }else{
        product__list.empty();
    }
    product__list.empty();
});

 // Calculate on change of quantity Product Item
$(document).on('change', '.product__quantityInsert', function(e){
    let product__quantityInsert = $(this).val();
    let product__quantityNumber = Number(product__quantityInsert);
    let product__priceInsert = $(this).closest('.product__item').find('.product__priceInsert').val();
    let product__priceNumber = Number(product__priceInsert);
    let product__sum = $(this).closest('.product__item').find('.product__sum');
    let product__insertSum = $(this).closest('.product__item').find('.product__insertSum');
    let product__total = product__priceInsert * product__quantityInsert;
    product__insertSum.text(product__total);
    product__sum.val(product__total);
});
// Calculate on change of price on Product Item
$(document).on('change', '.product__priceInsert', function(e){
    let product__priceInsert = $(this).val();
    let product__priceNumber = Number(product__priceInsert);
    let product__quantityInsert = $(this).closest('.product__item').find('.product__quantityInsert').val();
    let product__quantityNumber = Number(product__quantityInsert);
    let product__sum = $(this).closest('.product__item').find('.product__sum');
    let product__insertSum = $(this).closest('.product__item').find('.product__insertSum');
    let product__total = product__priceInsert * product__quantityInsert;
    product__insertSum.text(product__total);
    product__sum.val(product__total);

   
});