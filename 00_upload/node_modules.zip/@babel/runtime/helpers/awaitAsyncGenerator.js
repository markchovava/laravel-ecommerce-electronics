var AwaitValue = require("./AwaitValue.js");

function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}

module.exports = _awaitAsyncGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;