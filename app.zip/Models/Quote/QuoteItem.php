<?php

namespace App\Models\Quote;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuoteItem extends Model
{
    use HasFactory;
    protected $fillable = [
        'quote_id',
        'product_name',
        'description',
        'quantity',
        'price',
        'zw_price',
        'total',
        'zw_total'
    ];

    public function products(){
        return $this->belongsTo(QuoteItem::class, 'quote_id', 'id');
    }
}
