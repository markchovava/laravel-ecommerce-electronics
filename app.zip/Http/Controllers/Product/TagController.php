<?php

namespace App\Http\Controllers\Product;

use App\Http\Controllers\Controller;
use App\Models\Product\Tag;
use Illuminate\Http\Request;

class TagController extends Controller
{
    public function index(){}
    public function add(){}
    public function store(){}
    public function edit(){}
    public function update(){}
    public function delet(){}
    public function search(){}
}
