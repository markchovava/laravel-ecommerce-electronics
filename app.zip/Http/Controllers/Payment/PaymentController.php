<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

use App\Models\Payment\PaymentDetail;
use Paynow\Payments\Paynow;

class PaymentController extends Controller
{
    public function index(){

        $paynow = new Paynow(
            env('PAYNOW_KEY'),
            env('PAYNOW_ID'),
            'http://lunartechstore.co.zw/checkout',

            // The return url can be set at later stages. You might want to do this if you want to pass data to the return url (like the reference of the transaction)
            'http://lunartechstore.co.zw/track/order'
        ); 

        # $paynow->setResultUrl('');
        # $paynow->setReturnUrl('');
        $reference_id = Session::get('reference_id');
        $email = Session::get('email');
        $total = 1.25;
        $payment = $paynow->createPayment($reference_id, $email);
        
        //dd($reference_id ,  $email);
        $payment->add($reference_id, $total);
        // Initiate a Payment 
        $data['response']= $paynow->send($payment);
        if(!$data['response']->success){
            $data['result'] = $data['response']->error;
        }
        else{
            $data['result'] = $data['response'];
        }

        $data['pay'] = $payment->total;

        /* 
            * Add Payment Detials
            */
           /*  $pay = new PaymentDetail();
            $pay->order_id = $order->id; 
            $pay->amount = $order->total; 
            $pay->zwl_amount = $order->zwl_total; 
            $pay->currency = $order->currency; 
            $pay->method = $order->payment_method; 
            //$pay->status = $status; 
            $pay->poll_url = $pollUrl; 
            $pay->created_at = now();
            $pay->save(); */
        return view('frontend.pages.payment.index', $data);
    }



}
