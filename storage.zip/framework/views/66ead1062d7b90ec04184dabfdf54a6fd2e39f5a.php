<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1> <?php echo e($product->name); ?> </h1>
    <?php if( intval($product->discounts->discount_percent) > 0): ?>
    <p> The Discount: <?php echo e(intval($product->discounts->discount_percent)); ?>% </p>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\02_laravel\laravel-lunartech\resources\views/frontend/test.blade.php ENDPATH**/ ?>